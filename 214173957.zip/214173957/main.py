from finder import finder

def main():
    a = finder()
    a.find(a.getData())


if __name__ == "__main__":
    main()